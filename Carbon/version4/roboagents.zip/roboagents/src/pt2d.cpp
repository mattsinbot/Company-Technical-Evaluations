#include "pt2d.h"

pt2d::pt2d(int a, int b) {x =a; y = b;}
int pt2d::getpt_x(){return x;}
int pt2d::getpt_y(){return y;}
